#e=int(input("entrer un nombre:"))
#f nombre%2==0:
 # print("nombre est:",paire)     
#lse: 
# print("nombre est:",impaire)
   
 
 
#bre1=float(input("entrer premier nombre:"))
#bre2=float(input("entrer un second nombre:"))
#f nbre1>nbre2:
 #   print("nbre le plus grand est:",nbre1)
#lse:
 
  # print ("le plus grand est",nbre2)
 
 
 
 
 
 
#b=int(input("entrer un nombre:"))
#f nb<0:
#   print(nb,"est negatif")
#lif nb>0:
 #  print(nb,"est positif")    
#lse:
 # print(nb,"est nul")
 
 
 
 
#a=int(input("entrer un nombre:"))
#b=int(input("entrer un second:"))
#produit=a*b
#if a*b<0:
 # print(a,'*',b,"est négatif")
#elif a*b>0:
 # print(a,'*',b,"est positif")
#else:
 # print(a,'*',b,"est nul")
  
  
  
#caractere=input("entrer un caractere:")
#if caractere=='o':
 # print(caractere,"affirmatif")
#elif caractere=='n':
 # print(caractere,"negatif")
#else :
 # print(caractere,"?!?!?!")
  
  
  
  
#nom1=input("entrer un nom:")
#nom2=input("entrer unsecond nom:")
#nom3=input("entrer un autre nom:")
#if nom1<nom2 and nom2<nom3:
 # print(nom1,nom2,nom3,"sont rangés")
#else:
 # print(nom1,nom2,nom3,"ne sont pas rangés")
 
 
 
 
 
 
 
 
#age=int(input("entrer un age:"))
#if age>=18:
 #  print(age,"vous etes majeurs")
#elif age>=13:
 #  print(age,"vous etes adolescent")
#else:
 #  print(age,"vous etes enfants")
 
 
 
 
#heure=int(input("entrer l heure:"))
#minute=int(input("entrer la minute:"))
#if heure >24:
#  heure=0
#minute+=1
#if minute>60:
#   minute=0
#print("dans une il sera",heure,"h",minute,"min")    
    
    
    
    
#vol_tranche=[10,10,30,50]
#pu=[190,380,400,425,500]
#tva=[1,1.15,1.15,1.15,1.15]  
#ligne=0
#prix=0        
#while reste>0:
#  if ligne<len(vol_tranche) and reste>vol_tranche[ligne]:
 #  reste=reste-vol_tranche[ligne]
  # prix+=vol_tranche[ligne]*pu[ligne]*tva[ligne]
   #ligne+=1
  #else:
   #  prix+=reste*pu[ligne]*tva[ligne]
    # reste=0
#print(prix)        
   
    
    
#conso=int(input("entrer la consommation:"))
#if conso<=10:
#  prix=conso*190*1
 # print(prix)
#elif conso<= 20:
 # prix=(10*190*1)+(conso-10)*380*1.15
 # print(prix)
#elif conso<=50:
 # prix=(10*190*1)+(10*380*1.15)+(conso-20)*400*1.15
 # print(prix)
#elif conso<=100:
 # prix=(10*190*1)+(10*380*1.15)+(30*400*1.15)+(conso-50)*425*1.15
 # print(prix)
#else:
 # prix=(10*190*1)+(10*380*1.15)+(30*400*1.15)+(50*425*1.15)+(conso-100)*500*1.15
#print(prix)  
  
    
    
    
    
    
    
#import random
#carte=input("entrer une pile ou une face:")
#nbre=random.randint(0,1)
#if nbre==0 and carte=="p":
#    print("vous avez gagne")
#elif nbre==0 and carte=="f":    
 #   print("vous avez perdu")
#elif nbre==1 and carte=="f":
 #   print("vous avez gagne")
#elif nbre==1 and carte=="p":
#    print("vous avez perdu")    
    
    
    
    
    
    
    
    
    
    
    
#x=10    
#def fonction():
 #   print(x)
 #   global x
  #  x=20
  #  print(x)
#fonction()
#print(x)    
    
   
#def somme_n(n):
 #  if n ==0:
  #   return 0
   #else:      
    #return 
    
    
    
    
    
 #   =1×2×3×⋯×n⏟=n! ×(n+1)=f(n)×(n+1).
    
    
    
    
#def factoriel(n):
 #  while n!*(n+1)=f(n)*(n+1):
  #   return (1*2*3*..*n
    
    
    
    
T=[8,15,3,9,2,1]   
def tri_insertion():
 v=len(T)
 for i in range(0,v):
   x=T[i]
   T[0]=T[i-1]
   j=i
 while j>0 and T[j-1]>x:
   j=j-1
   x= T[j]
   print(T)  
tri_insertion()

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    


  

 
 
      
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  

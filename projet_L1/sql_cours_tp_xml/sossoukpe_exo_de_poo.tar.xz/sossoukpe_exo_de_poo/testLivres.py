from Livres import Livres
l = Livres("amour pour debutants","kodjo",20,300)
l.afficher_details()
l.modifier_prix(88)
l.afficher_details()


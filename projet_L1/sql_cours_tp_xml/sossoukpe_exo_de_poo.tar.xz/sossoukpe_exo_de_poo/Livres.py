
class Livres:
    def __init__(self,titre,auteur,prix,nombre_pages):
        self.titre = titre
        self.auteur = auteur
        self.prix = prix
        self.nombre_pages = nombre_pages
    def modifier_prix(self,nouveau_prix):
        self.prix = nouveau_prix
    def afficher_details(self):
        print(f"titre :{self.titre}")
        print(f"auteur:{self.auteur}")
        print(f"prix:{self.prix}")
        print(f"nombre_page:{self.nombre_pages}")

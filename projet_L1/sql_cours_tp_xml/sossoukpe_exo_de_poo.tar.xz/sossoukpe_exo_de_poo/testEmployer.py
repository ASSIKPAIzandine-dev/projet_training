from Employer import Employer
e=Employer("sossoukpe",350)
e.afficher()
e.augmenter_salaire(500)
e.afficher()
e.retenue_sur_salaire(500)
e.afficher()

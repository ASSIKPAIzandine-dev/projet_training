from Cercle import Cercle
from Point import Point
c = Cercle(0,0,5)
point = Point (3, 4)
print(c.surface())
print(c.perimetre())
print(c.testappartenance(point))


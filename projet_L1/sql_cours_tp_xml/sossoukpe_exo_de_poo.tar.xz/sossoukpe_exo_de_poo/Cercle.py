import math
import Point
class Cercle:
    def __init__(self,a,b,rayon):
        self.x = a
        self.y = b
        self.r = rayon
    def surface(self):
        return math.pi * (self.r ** 2)    
    def perimetre(self):
        return 2 * math.pi* self.r
    def testappartenance(self,point:Point):
        distance = math.sqrt((point.x - self.x)**2 + (point.y - self.y)**2)
        return distance <= self.r 
    

        

class Employer:
    def __init__(self,nom,salaire):
        self.nom = nom
        self.salaire = salaire
        
    def augmenter_salaire(self,montant):
        self.salaire += montant
        
    def retenue_sur_salaire(self,montant):
        self.salaire -=montant
    def afficher(self):
        print(f"nom:{self.nom}")
        print(f"salaire:{self.salaire} F")
